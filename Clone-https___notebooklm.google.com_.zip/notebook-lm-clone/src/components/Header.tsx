"use client";

import { Button } from "@/components/ui/button";
import { Menu, Sun, Share } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useState } from "react";

interface HeaderProps {
  notebookTitle?: string;
  onToggleSidebar: () => void;
}

export default function Header({ notebookTitle = "", onToggleSidebar }: HeaderProps) {
  const [theme, setTheme] = useState<"light" | "dark">("light");

  const toggleTheme = () => {
    setTheme(theme === "light" ? "dark" : "light");
    // This would normally toggle a class on the document or use a theme provider
  };

  return (
    <header className="flex items-center justify-between h-16 px-4 border-b bg-background">
      <div className="flex items-center space-x-4">
        <Button variant="ghost" size="icon" onClick={onToggleSidebar}>
          <Menu className="h-5 w-5" />
        </Button>
        <div className="flex items-center">
          <span className="font-semibold text-xl">NotebookLM</span>
          <span className="ml-2 text-xs px-2 py-0.5 bg-muted text-muted-foreground rounded-full">
            EXPERIMENTAL
          </span>
        </div>
        {notebookTitle && (
          <>
            <div className="h-6 border-l mx-2" />
            <h1 className="text-xl font-medium">{notebookTitle}</h1>
          </>
        )}
      </div>
      <div className="flex items-center space-x-2">
        <Button variant="ghost" size="icon" onClick={toggleTheme}>
          <Sun className="h-5 w-5" />
        </Button>
        {notebookTitle && (
          <>
            <Button variant="ghost" size="sm">
              Discord
            </Button>
            <Button variant="outline" size="sm" className="flex items-center gap-1.5">
              <Share className="h-4 w-4" />
              Share
            </Button>
          </>
        )}
        <Avatar className="h-8 w-8">
          <AvatarImage src="/avatar-placeholder.png" />
          <AvatarFallback>U</AvatarFallback>
        </Avatar>
      </div>
    </header>
  );
}
