"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText } from "lucide-react";

export interface NoteCardProps {
  id: string;
  title: string;
  content: string;
  type: "response" | "note";
  onClick?: () => void;
}

export default function NoteCard({ title, content, type, onClick }: NoteCardProps) {
  return (
    <Card
      className="h-80 overflow-hidden cursor-pointer hover:border-primary/50 transition-colors"
      onClick={onClick}
    >
      <CardHeader className="p-4 pb-0 space-y-0">
        <div className="flex items-center text-sm text-muted-foreground mb-3">
          {type === "response" ? (
            <div className="flex items-center gap-1.5">
              <FileText className="h-4 w-4" />
              <span>Saved Response</span>
            </div>
          ) : (
            <div className="flex items-center gap-1.5">
              <FileText className="h-4 w-4" />
              <span>Written Note</span>
            </div>
          )}
        </div>
        <CardTitle className="text-base font-medium">New note</CardTitle>
      </CardHeader>
      <CardContent className="p-4 pt-2">
        <h3 className="text-lg font-medium mb-3">{title}</h3>
        <p className="text-sm text-muted-foreground line-clamp-6">
          {content}
        </p>
      </CardContent>
    </Card>
  );
}
