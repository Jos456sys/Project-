"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Plus, CheckSquare } from "lucide-react";
import NoteCard, { type NoteCardProps } from "./NoteCard";
import ChatInput from "./ChatInput";

interface NotebookPageProps {
  notebookId: string;
  notebookTitle: string;
}

export default function NotebookPage({ notebookId, notebookTitle }: NotebookPageProps) {
  const [notes, setNotes] = useState<NoteCardProps[]>([
    {
      id: "1",
      title: "Timeline of Main Events",
      content: "This timeline tracks the development and impact of Generative AI, specifically large language models (LLMs) like ChatGPT, on education and writing practices, based on the provided source material.",
      type: "response",
    },
    {
      id: "2",
      title: "Generative AI and Multimodal Texts in Education: A Study Guide",
      content: "This study guide explores the intersection of generative AI technologies like large language models and multimodal content in educational contexts, examining their impact on teaching and learning practices.",
      type: "response",
    },
    {
      id: "3",
      title: "Generative AI in Education: An FAQ",
      content: "1. How can educators use generative AI effectively in curriculum design? While generative AI cannot design a whole curriculum for you, the DRC (Design, Refine, Create) framework can be used alongside existing curriculum design approaches.",
      type: "response",
    },
  ]);

  const handleSendMessage = (message: string) => {
    console.log("Sending message:", message);
    // In a real app, this would communicate with an API
  };

  return (
    <div className="flex flex-col h-full">
      <div className="p-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Button variant="outline" className="gap-1.5">
            <Plus className="h-4 w-4" />
            Add note
          </Button>
          <Button variant="ghost" className="gap-1.5">
            <CheckSquare className="h-4 w-4" />
            Select all
          </Button>
        </div>
      </div>

      <div className="flex-1 p-4 overflow-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {notes.map((note) => (
          <NoteCard
            key={note.id}
            id={note.id}
            title={note.title}
            content={note.content}
            type={note.type}
          />
        ))}
      </div>

      <div className="mt-auto">
        <ChatInput
          onSendMessage={handleSendMessage}
          sourcesCount={5}
        />
      </div>
    </div>
  );
}
