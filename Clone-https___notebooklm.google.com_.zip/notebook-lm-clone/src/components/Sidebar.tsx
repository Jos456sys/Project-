"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, FileText, Check } from "lucide-react";
import { useState } from "react";

interface Source {
  id: string;
  title: string;
  type: "pdf";
  selected: boolean;
}

interface SidebarProps {
  isOpen: boolean;
}

export default function Sidebar({ isOpen }: SidebarProps) {
  const [sources, setSources] = useState<Source[]>([
    { id: "1", title: "Design Refine Create", type: "pdf", selected: true },
    { id: "2", title: "Flattening the Strata of LLMs", type: "pdf", selected: true },
    { id: "3", title: "How Artificial Intelligence Changes Writing", type: "pdf", selected: true },
    { id: "4", title: "Multimodal Discourse Analysis", type: "pdf", selected: true },
    { id: "5", title: "The Myth of the AI First Principle", type: "pdf", selected: true },
  ]);

  const [allSelected, setAllSelected] = useState(true);

  const toggleSource = (id: string) => {
    setSources(
      sources.map((source) =>
        source.id === id ? { ...source, selected: !source.selected } : source
      )
    );

    // Update allSelected state based on the new selection state
    const updatedSources = sources.map((source) =>
      source.id === id ? { ...source, selected: !source.selected } : source
    );
    setAllSelected(updatedSources.every((source) => source.selected));
  };

  const toggleAllSources = () => {
    const newState = !allSelected;
    setAllSelected(newState);
    setSources(sources.map((source) => ({ ...source, selected: newState })));
  };

  if (!isOpen) return null;

  return (
    <aside className="w-72 h-full border-r bg-background flex flex-col overflow-hidden">
      <div className="flex items-center justify-between p-4 border-b">
        <div className="flex items-center">
          <span className="text-sm font-medium">Sources</span>
          <div className="ml-2 w-5 h-5 rounded-full bg-muted flex items-center justify-center text-xs">
            {sources.length}
          </div>
        </div>
        <Button variant="ghost" size="icon">
          <Plus className="h-4 w-4" />
        </Button>
      </div>

      <div className="p-4 border-b">
        <div
          className="flex items-center mb-2 cursor-pointer"
          onClick={toggleAllSources}
        >
          <div className="w-5 h-5 rounded border mr-2 flex items-center justify-center">
            {allSelected && <Check className="h-3 w-3" />}
          </div>
          <span className="text-sm">Select all sources</span>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-2">
        {sources.map((source) => (
          <div
            key={source.id}
            className="flex items-center p-2 hover:bg-muted rounded-md cursor-pointer"
            onClick={() => toggleSource(source.id)}
          >
            <div className="w-5 h-5 rounded border mr-2 flex items-center justify-center text-primary-foreground bg-primary">
              {source.selected && <Check className="h-3 w-3" />}
            </div>
            <FileText className="text-primary mr-2 h-5 w-5" />
            <span className="text-sm line-clamp-1">{source.title}</span>
          </div>
        ))}
      </div>
    </aside>
  );
}
