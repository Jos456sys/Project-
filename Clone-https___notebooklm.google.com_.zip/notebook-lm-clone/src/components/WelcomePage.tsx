"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Upload, MessageSquare, Users } from "lucide-react";

interface WelcomePageProps {
  onCreateNotebook: () => void;
}

export default function WelcomePage({ onCreateNotebook }: WelcomePageProps) {
  return (
    <div className="h-full w-full flex flex-col items-center justify-center px-4 py-12 bg-gradient-to-br from-blue-50 to-purple-50">
      <div className="max-w-3xl w-full text-center">
        <h1 className="text-4xl font-bold mb-6">Create your first notebook</h1>
        <p className="text-xl text-muted-foreground mb-12">
          NotebookLM is an AI-powered research and writing assistant that works best with the sources you upload
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Card className="bg-white shadow-sm h-56">
            <CardContent className="flex flex-col items-center justify-center h-full text-center p-6">
              <div className="w-14 h-14 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                <Upload className="h-6 w-6 text-blue-500" />
              </div>
              <h3 className="text-lg font-medium mb-2">Upload your documents</h3>
              <p className="text-sm text-muted-foreground">
                NotebookLM will answer detailed questions or surface key insights
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm h-56">
            <CardContent className="flex flex-col items-center justify-center h-full text-center p-6">
              <div className="w-14 h-14 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                <MessageSquare className="h-6 w-6 text-blue-500" />
              </div>
              <h3 className="text-lg font-medium mb-2">Convert complex material</h3>
              <p className="text-sm text-muted-foreground">
                Transform difficult content into easy-to-understand formats like FAQs or briefing docs
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm h-56">
            <CardContent className="flex flex-col items-center justify-center h-full text-center p-6">
              <div className="w-14 h-14 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                <Users className="h-6 w-6 text-blue-500" />
              </div>
              <h3 className="text-lg font-medium mb-2">Share with your team</h3>
              <p className="text-sm text-muted-foreground">
                Add resources to a notebook and share with your organization to create a group knowledge base
              </p>
            </CardContent>
          </Card>
        </div>

        <Button
          size="lg"
          className="px-8 text-base font-medium"
          onClick={onCreateNotebook}
        >
          Create
        </Button>

        <div className="mt-6">
          <button className="text-blue-600 text-sm hover:underline">
            Try an example notebook
          </button>
        </div>
      </div>

      <div className="mt-16 text-sm font-medium">Example notebooks</div>
    </div>
  );
}
