"use client";

import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { MessageSquare, SendHorizonal } from "lucide-react";
import { useState } from "react";

interface ChatInputProps {
  onSendMessage: (message: string) => void;
  placeholder?: string;
  sourcesCount?: number;
}

export default function ChatInput({
  onSendMessage,
  placeholder = "Start typing...",
  sourcesCount = 0
}: ChatInputProps) {
  const [message, setMessage] = useState("");

  const handleSend = () => {
    if (message.trim()) {
      onSendMessage(message);
      setMessage("");
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="border-t bg-muted/30 p-4">
      <div className="flex items-center justify-between mb-2">
        <Button variant="ghost" className="text-xs flex items-center gap-1.5">
          <MessageSquare className="h-3.5 w-3.5" />
          View Chat
        </Button>
        {sourcesCount > 0 && (
          <div className="text-xs text-muted-foreground">
            {sourcesCount} sources
          </div>
        )}
      </div>
      <div className="relative">
        <Textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          className="min-h-24 pr-10 bg-background resize-none"
        />
        <Button
          size="icon"
          className="absolute bottom-3 right-3 rounded-full"
          onClick={handleSend}
          disabled={!message.trim()}
        >
          <SendHorizonal className="h-4 w-4" />
        </Button>
      </div>
      <div className="mt-2 flex justify-center text-xs text-muted-foreground">
        NotebookLM may still sometimes give inaccurate responses, so you may want to confirm any facts independently.
      </div>
    </div>
  );
}
