"use client";

import { useState } from "react";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import WelcomePage from "@/components/WelcomePage";
import NotebookPage from "@/components/NotebookPage";

export default function Home() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activeNotebook, setActiveNotebook] = useState<{ id: string; title: string } | null>(null);

  const toggleSidebar = () => setSidebarOpen(!sidebarOpen);

  const handleCreateNotebook = () => {
    // In a real app, this would make an API call to create a notebook
    setActiveNotebook({
      id: "notebook-1",
      title: "Blog notebook"
    });
  };

  return (
    <div className="flex flex-col h-screen">
      <Header
        notebookTitle={activeNotebook?.title}
        onToggleSidebar={toggleSidebar}
      />

      <div className="flex flex-1 overflow-hidden">
        {activeNotebook && (
          <Sidebar isOpen={sidebarOpen} />
        )}

        <main className="flex-1 overflow-hidden">
          {activeNotebook ? (
            <NotebookPage
              notebookId={activeNotebook.id}
              notebookTitle={activeNotebook.title}
            />
          ) : (
            <WelcomePage onCreateNotebook={handleCreateNotebook} />
          )}
        </main>
      </div>
    </div>
  );
}
