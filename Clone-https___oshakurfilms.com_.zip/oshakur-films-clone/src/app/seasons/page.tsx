import React from "react";
import Header from "@/components/header";
import Footer from "@/components/footer";
import Link from "next/link";
import Image from "next/image";
import { Calendar } from "lucide-react";

export default function SeasonsPage() {
  const seasons = [
    {
      id: "the-shield-rocky",
      title: "THE SHIELD - ROCKY",
      image: "https://res.cloudinary.com/deucltufy/image/upload/v1743413414/OSHAkurFilms/eups2wkereatjv8stjk5.jpg",
      category: "ACTION",
      episodes: 0,
    },
    {
      id: "ashok-samrat-ep1-yakuza",
      title: "ASHOK SAMRAT - YAKUZA",
      image: "https://res.cloudinary.com/deucltufy/image/upload/v1743354551/OSHAkurFilms/otkx9zenxiqkdwttpwym.jpg",
      category: "INDIAN",
      episodes: 10,
    },
    {
      id: "cassandra-ep1-habibu",
      title: "CASSANDRA - HABIBU",
      image: "https://res.cloudinary.com/deucltufy/image/upload/v1743266645/OSHAkurFilms/w06ao0bdynxnqa8xxrhf.jpg",
      category: "SCIFI",
      episodes: 6,
    },
    {
      id: "nine-bodie-ep1-gaheza",
      title: "NIine Bodie - Gaheza",
      image: "https://res.cloudinary.com/deucltufy/image/upload/v1743263349/OSHAkurFilms/cj4rxfb61xlzffpy5jsh.jpg",
      category: "ACTION",
      episodes: 4,
    },
    {
      id: "house-of-david-ep1-savimbi",
      title: "House of David - SAVIMBI",
      image: "https://res.cloudinary.com/deucltufy/image/upload/v1742920194/OSHAkurFilms/x0zivggebkgm4jgsihba.jpg",
      category: "DRAMA",
      episodes: 7,
    },
    {
      id: "house-of-david-ep1-habibu",
      title: "House of David - HABIBU",
      image: "https://res.cloudinary.com/deucltufy/image/upload/v1742687351/OSHAkurFilms/dyqqx1afvsldslpuqcrb.jpg",
      category: "DRAMA",
      episodes: 5,
    },
    {
      id: "beauty-in-black-e1-rocky",
      title: "Beauty in Black - ROCKY",
      image: "https://res.cloudinary.com/dofeqwgfb/image/upload/v1741843109/OSHAkurFilms/gkri8ekloigaz6jsvyqe.jpg",
      category: "DRAMA",
      episodes: 15,
    },
    {
      id: "who-killed-sara-ep1-rocky",
      title: "Who Killed Sara? - ROCKY",
      image: "https://res.cloudinary.com/dofeqwgfb/image/upload/v1741730060/OSHAkurFilms/frwkjimipvwovgs3g35f.jpg",
      category: "DRAMA",
      episodes: 10,
    },
    {
      id: "lioness-ep1-rocky",
      title: "LIONESS - ROCKY",
      image: "https://res.cloudinary.com/dofeqwgfb/image/upload/v1741583395/OSHAkurFilms/ddsnv2cf3a0gosewu9vp.jpg",
      category: "ACTION",
      episodes: 8,
    },
    {
      id: "fatal-seductio-ep1-rocky",
      title: "Fatal Seduction - ROCKY",
      image: "https://res.cloudinary.com/dofeqwgfb/image/upload/v1740830042/OSHAkurFilms/upq3k95tfotjplwziycl.jpg",
      category: "ACTION",
      episodes: 14,
    },
    {
      id: "master-of-the-air-ep1-master-p",
      title: "MASTER OF THE AIR - MASTER P",
      image: "https://res.cloudinary.com/dofeqwgfb/image/upload/v1740765835/OSHAkurFilms/jkzxoqylpftqux3qnxr6.jpg",
      category: "ACTION",
      episodes: 9,
    },
    {
      id: "diary-of-a-gigolo-ep1-sankra",
      title: "Diary of a Gigolo - SANKRA",
      image: "https://res.cloudinary.com/dofeqwgfb/image/upload/v1740664096/OSHAkurFilms/hqdqmkmxr4umkuz181br.jpg",
      category: "ROMANCE",
      episodes: 10,
    },
    {
      id: "vikings-ep1-rocky",
      title: "VIKINGS S1 - ROCKY",
      image: "https://res.cloudinary.com/dofeqwgfb/image/upload/v1740301226/OSHAkurFilms/dybtvt4sybdsswyz1i52.jpg",
      category: "ACTION",
      episodes: 9,
    },
    {
      id: "the-rings-of-the-power-ep1-pk",
      title: "The Rings of Power - PK",
      image: "https://res.cloudinary.com/dofeqwgfb/image/upload/v1739816893/OSHAkurFilms/wujkfkihdwze5nniveep.jpg",
      category: "ACTION",
      episodes: 4,
    },
    {
      id: "from-s2ep1-sankra",
      title: "From S2 - Sankra",
      image: "https://res.cloudinary.com/dofeqwgfb/image/upload/v1739816850/OSHAkurFilms/gjxpkfxctjauyjoznomk.jpg",
      category: "HORROR",
      episodes: 10,
    },
  ];

  const categories = [
    { name: "All", count: seasons.length },
    { name: "ACTION", count: seasons.filter(s => s.category === "ACTION").length },
    { name: "DRAMA", count: seasons.filter(s => s.category === "DRAMA").length },
    { name: "SCIFI", count: seasons.filter(s => s.category === "SCIFI").length },
    { name: "HORROR", count: seasons.filter(s => s.category === "HORROR").length },
    { name: "ROMANCE", count: seasons.filter(s => s.category === "ROMANCE").length },
    { name: "INDIAN", count: seasons.filter(s => s.category === "INDIAN").length },
  ];

  return (
    <main className="bg-oshakur-darkBg min-h-screen">
      <Header />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8 flex items-center gap-3">
          <Calendar size={24} className="text-oshakur-red" />
          <h1 className="text-3xl font-bold text-white">Hot Seasons</h1>
        </div>

        {/* Categories filter */}
        <div className="mb-8 overflow-x-auto">
          <div className="flex gap-2 pb-2">
            {categories.map((category) => (
              <button
                key={category.name}
                className={`px-4 py-2 rounded-md whitespace-nowrap ${
                  category.name === "All"
                    ? "bg-oshakur-red text-white"
                    : "bg-oshakur-darkBg2 text-gray-300 hover:bg-gray-800"
                }`}
              >
                {category.name} ({category.count})
              </button>
            ))}
          </div>
        </div>

        {/* Seasons grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 md:gap-6">
          {seasons.map((season) => (
            <Link key={season.id} href={`/watch/${season.id}`} className="group block">
              <div className="relative aspect-[3/4] rounded-lg overflow-hidden mb-2">
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent z-10" />

                <div className="absolute top-2 left-2 bg-oshakur-red text-white px-2 py-1 text-xs font-semibold rounded z-20">
                  {season.category}
                </div>

                <Image
                  src={season.image}
                  alt={season.title}
                  fill
                  className="object-cover transition-transform duration-300 group-hover:scale-110"
                />

                <div className="absolute bottom-0 left-0 p-3 z-20 w-full">
                  <h3 className="text-white font-bold">{season.title}</h3>
                  <p className="text-gray-300 text-sm">
                    {season.episodes} episodes
                  </p>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      <Footer />
    </main>
  );
}
