import React from "react";
import Image from "next/image";
import Link from "next/link";
import Header from "@/components/header";
import Footer from "@/components/footer";
import MovieSection from "@/components/movie-section";
import { Download, Monitor } from "lucide-react";

interface PageProps {
  params: {
    slug: string;
  };
}

export default function Watch({ params }: PageProps) {
  const { slug } = params;

  // Mock movie data based on the slug (in a real app this would be fetched from an API)
  const movie = {
    id: slug,
    title: slug.split("-").map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(" "),
    description: "The movie *Trap* (2024) is a psychological thriller directed by M. Night Shyamalan. It follows the story of Cooper, a firefighter who secretly leads a double life as a serial killer known as \"The Butcher.\" The plot unfolds as Cooper takes his daughter, Riley, to a concert by pop star Lady Raven. Unbeknownst to him, the concert is a setup by the FBI to capture him. The film explores themes of deception, family bonds, and the tension between Cooper's two identities. It received mixed reviews but was noted for its suspenseful storytelling.",
    category: "ACTION",
    watchUrl: "https://cybervynx.com/gzkr6xksn4ue",
    downloadUrl: "https://www.mediafire.com/file/2sceqtqoimsmv1f/TRAP.mp4/file",
    youtubeTrailerId: "hJiPAJKjUVg",
  };

  // Sample comments
  const comments = [
    { name: "Fabrixe", text: "Bro wazaduhaye Last Ship", time: "8 hours ago" },
    { name: "prince", text: "Dutemo:black widow ya sankra", time: "11 hours ago" },
    { name: "Bellox", text: "Ese brother wazaduhaye hitman agent 47", time: "a day ago" },
    { name: "viewer1", text: "ese kuberiki yo hagize connection problem bihita bipfa utakongera ku reloading simply?", time: "a day ago" },
    { name: "Desire", text: "Murikuzibona gutx abax", time: "a day ago" },
    { name: "Veda", text: "Trap 2 please", time: "a day ago" },
  ];

  // Similar movies for "More Films" section
  const moreFilms = [
    {
      id: "ashok-samrat-ep10-yakuza",
      title: "ASHOK SAMRAT Ep10 - YAKUZA",
      image: "https://res.cloudinary.com/dofeqwgfb/image/upload/v1743627146/OSHAkurFilms/tyytsa18tldkkbjoxicv.jpg",
      timestamp: "3 hours ago",
    },
    {
      id: "ashok-samrat-ep9-yakuza",
      title: "ASHOK SAMRAT Ep9 - YAKUZA",
      image: "https://res.cloudinary.com/dofeqwgfb/image/upload/v1743626957/OSHAkurFilms/shdiogkhagndxfdlkvtv.jpg",
      timestamp: "3 hours ago",
    },
    {
      id: "ashok-samrat-ep8-yakuza",
      title: "ASHOK SAMRAT Ep8 - YAKUZA",
      image: "https://res.cloudinary.com/dofeqwgfb/image/upload/v1743540690/OSHAkurFilms/r8afdj9bqnmn0cqstzdn.jpg",
      timestamp: "a day ago",
    },
    {
      id: "ashok-samrat-ep7-yakuza",
      title: "ASHOK SAMRAT Ep7 - YAKUZA",
      image: "https://res.cloudinary.com/dofeqwgfb/image/upload/v1743540582/OSHAkurFilms/v3vxxuxtoo9br4nbuxiy.jpg",
      timestamp: "a day ago",
    },
    {
      id: "winabi-savimbi",
      title: "WINABI - SAVIMBI",
      image: "https://res.cloudinary.com/dofeqwgfb/image/upload/v1743461523/OSHAkurFilms/jvd47elrh7axcqvsvixi.jpg",
      timestamp: "2 days ago",
    },
    {
      id: "house-of-david-ep7-savimbi",
      title: "House of David ep7 - Savimbi",
      image: "https://res.cloudinary.com/dofeqwgfb/image/upload/v1743460993/OSHAkurFilms/mbh4ppiagftbaiw7wfap.jpg",
      timestamp: "2 days ago",
    },
    {
      id: "ashok-samrat-ep6-yakuza",
      title: "ASHOK SAMRAT Ep6 - YAKUZA",
      image: "https://res.cloudinary.com/dofeqwgfb/image/upload/v1743460051/OSHAkurFilms/vbhvf2axhtt0rcxfuist.jpg",
      timestamp: "2 days ago",
    },
    {
      id: "ashok-samrat-ep5-yakuza",
      title: "ASHOK SAMRAT Ep5 - YAKUZA",
      image: "https://res.cloudinary.com/dofeqwgfb/image/upload/v1743459676/OSHAkurFilms/f175iv92cxsowzfz159g.jpg",
      timestamp: "2 days ago",
    },
    {
      id: "ashok-samrat-ep4-yakuza",
      title: "ASHOK SAMRAT Ep4 - YAKUZA",
      image: "https://res.cloudinary.com/deucltufy/image/upload/v1743354148/OSHAkurFilms/meav90puxdx6anlh0yez.jpg",
      timestamp: "3 days ago",
    },
    {
      id: "ashok-samrat-ep3-yakuza",
      title: "ASHOK SAMRAT Ep3 - YAKUZA",
      image: "https://res.cloudinary.com/deucltufy/image/upload/v1743354027/OSHAkurFilms/oj7vsw6qy7qs6gq3pqhl.jpg",
      timestamp: "3 days ago",
    },
  ];

  return (
    <main className="bg-oshakur-darkBg text-white min-h-screen">
      <Header />

      <div className="container mx-auto px-4 py-6 max-w-6xl">
        <Link href="/" className="flex items-center gap-2 mb-6 text-gray-300 hover:text-white transition-colors">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M9.57 5.93L3.5 12L9.57 18.07" stroke="currentColor" strokeWidth="1.5" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M20.5 12H3.67" stroke="currentColor" strokeWidth="1.5" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          Go to Home
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            {/* YouTube video embed */}
            <div className="relative pb-[56.25%] h-0 mb-6">
              <iframe
                className="absolute top-0 left-0 w-full h-full rounded-lg"
                src={`https://www.youtube.com/embed/${movie.youtubeTrailerId}`}
                title={`${movie.title} Trailer`}
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              ></iframe>
            </div>

            <h1 className="text-3xl font-bold mb-4">
              {movie.title}
            </h1>

            <div className="flex flex-wrap gap-4 mb-8">
              <Link
                href={movie.watchUrl}
                target="_blank"
                className="red-button"
              >
                <Monitor className="h-4 w-4" />
                Watch Full Movie
              </Link>

              <Link
                href={movie.downloadUrl}
                target="_blank"
                className="bg-oshakur-darkBg2 hover:bg-gray-700 text-white px-4 py-2 rounded-md flex items-center gap-2 transition-colors"
              >
                <Download className="h-4 w-4" />
                Download
              </Link>

              <span className="bg-oshakur-red/80 text-white px-3 py-1 rounded text-sm font-medium">
                {movie.category}
              </span>
            </div>

            <div className="mb-12">
              <p className="text-gray-300 leading-relaxed">
                {movie.description}
              </p>
            </div>

            {/* Social links */}
            <div className="mb-12">
              <Link
                href="https://whatsapp.com/channel/0029VaeMnzYFcowEUV04lG0M"
                target="_blank"
                className="flex items-center gap-2 bg-green-800/20 text-green-400 p-3 rounded-md hover:bg-green-800/30 transition-colors max-w-fit"
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M17.6 6.31999C16.8669 5.58141 15.9943 4.99596 15.033 4.59767C14.0716 4.19938 13.0406 3.99602 12 3.99999C10.6089 4.00277 9.24248 4.36392 8.03271 5.04909C6.82295 5.73425 5.8093 6.71655 5.10469 7.9177C4.40008 9.11885 4.0271 10.482 4.0235 11.873C4.01989 13.264 4.38582 14.6292 5.086 15.834L4 20L8.252 18.943C9.41339 19.5609 10.6981 19.8826 12 19.877C14.1229 19.8647 16.1551 19.0151 17.6512 17.5082C19.1473 16.0013 19.9827 13.9631 19.9806 11.8401C19.9785 9.7172 19.1389 7.6809 17.6396 6.17699L17.6 6.31999Z" fill="currentColor" />
                </svg>
                Follow us on WhatsApp for movies updates
              </Link>
            </div>

            {/* Comments section */}
            <div>
              <h2 className="text-xl font-bold mb-6">Leave a comment</h2>

              <div className="mb-6">
                <div className="flex gap-4 mb-4">
                  <input
                    type="text"
                    placeholder="Display Name"
                    className="bg-oshakur-darkBg2 text-white p-2 rounded-md border border-gray-700 flex-1"
                  />
                  <input
                    type="text"
                    placeholder="Comment"
                    className="bg-oshakur-darkBg2 text-white p-2 rounded-md border border-gray-700 flex-2"
                  />
                </div>
              </div>

              <div className="border-t border-gray-800 pt-6">
                <h3 className="text-lg font-semibold mb-4">{comments.length} Comments</h3>

                <div className="space-y-6">
                  {comments.map((comment, index) => (
                    <div key={index} className="flex gap-3">
                      <div className="flex-shrink-0 w-8 h-8 bg-gray-700 rounded-full flex items-center justify-center text-white font-bold">
                        {comment.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-medium">{comment.name}</h4>
                          <span className="text-xs text-gray-400">{comment.time}</span>
                        </div>
                        <p className="text-gray-300">{comment.text}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div>
            <div className="bg-oshakur-darkBg2 rounded-lg p-6">
              <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M22 10.5V13.5C22 17.09 22 18.88 20.88 20C19.76 21.12 17.97 21.12 14.38 21.12H9.62C6.03 21.12 4.24 21.12 3.12 20C2 18.88 2 17.09 2 13.5V10.5C2 6.91 2 5.12 3.12 4C4.24 2.88 6.03 2.88 9.62 2.88H14.38C17.97 2.88 19.76 2.88 20.88 4C21.66 4.78 21.94 5.87 22 8.5" stroke="#BC1C21" strokeWidth="1.5" strokeLinecap="round"/>
                  <path d="M12 15.88V8.88" stroke="#BC1C21" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M16 11.88L12 7.88L8 11.88" stroke="#BC1C21" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
                More Films
              </h2>

              <div className="grid grid-cols-2 gap-3">
                {moreFilms.slice(0, 10).map((film) => (
                  <Link key={film.id} href={`/watch/${film.id}`} className="group">
                    <div className="relative aspect-[3/4] rounded-md overflow-hidden mb-2">
                      <Image
                        src={film.image}
                        alt={film.title}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <h3 className="text-sm font-medium line-clamp-2 group-hover:text-oshakur-red transition-colors">{film.title}</h3>
                    <p className="text-xs text-gray-400">{film.timestamp}</p>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </main>
  );
}
