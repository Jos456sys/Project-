import Image from "next/image";
import Header from "@/components/header";
import Hero from "@/components/hero";
import MovieSection from "@/components/movie-section";
import Footer from "@/components/footer";
import { Calendar, Flame, Clock, Clapperboard, Video, Tv, Users, BookOpen, HeartPulse, Laugh } from "lucide-react";

export default function Home() {
  // Sample featured movie
  const featuredMovie = {
    id: "trap-rocky",
    title: "TRAP - ROCKY",
    image: "https://ext.same-assets.com/2189201408/849522504.jpeg",
    releaseDate: "3 days ago",
  };

  // Sample data for trending movies
  const trendingMovies = [
    {
      id: "trap-rocky",
      title: "TRAP - ROCKY",
      image: "https://res.cloudinary.com/deucltufy/image/upload/v1743353788/OSHAkurFilms/icfuh96q9jxi5zogbyhi.jpg",
      timestamp: "3 days ago",
    },
    {
      id: "nadaaniyan-rocky",
      title: "Nadaaniyan - ROCKY",
      image: "https://res.cloudinary.com/deucltufy/image/upload/v1743173698/OSHAkurFilms/z9bzgzifkz6kwlpcadgh.jpg",
      timestamp: "5 days ago",
    },
    {
      id: "beauty-in-black-e14-rocky",
      title: "Beauty in Black E14 - ROCKY",
      image: "https://res.cloudinary.com/deucltufy/image/upload/v1742920147/OSHAkurFilms/v7wfjvsqwpx8pfyb2mbz.jpg",
      timestamp: "8 days ago",
    },
    {
      id: "be-happy-rocky",
      title: "Be Happy - ROCKY",
      image: "https://res.cloudinary.com/deucltufy/image/upload/v1742880506/OSHAkurFilms/x0cxliff3qh2vs5mvuee.jpg",
      timestamp: "9 days ago",
    },
    {
      id: "fateh-rocky",
      title: "FATEH - ROCKY",
      image: "https://res.cloudinary.com/dofeqwgfb/image/upload/v1741790011/OSHAkurFilms/ibn9p0i9nyyonlyubzus.jpg",
      timestamp: "21 days ago",
    },
    {
      id: "played-and-betrayed-sankra",
      title: "Played and Betrayed - SANKRA",
      image: "https://res.cloudinary.com/dofeqwgfb/image/upload/v1741384042/OSHAkurFilms/wpcgzoh3xnrb7zh3eowc.jpg",
      timestamp: "a month ago",
    },
  ];

  // Sample data for recent movies
  const recentMovies = [
    {
      id: "ashok-samrat-ep10-yakuza",
      title: "ASHOK SAMRAT Ep10 - YAKUZA",
      image: "https://res.cloudinary.com/dofeqwgfb/image/upload/v1743627146/OSHAkurFilms/tyytsa18tldkkbjoxicv.jpg",
      timestamp: "3 hours ago",
    },
    {
      id: "ashok-samrat-ep9-yakuza",
      title: "ASHOK SAMRAT Ep9 - YAKUZA",
      image: "https://res.cloudinary.com/dofeqwgfb/image/upload/v1743626957/OSHAkurFilms/shdiogkhagndxfdlkvtv.jpg",
      timestamp: "3 hours ago",
    },
    {
      id: "ashok-samrat-ep8-yakuza",
      title: "ASHOK SAMRAT Ep8 - YAKUZA",
      image: "https://res.cloudinary.com/dofeqwgfb/image/upload/v1743540690/OSHAkurFilms/r8afdj9bqnmn0cqstzdn.jpg",
      timestamp: "a day ago",
    },
    {
      id: "ashok-samrat-ep7-yakuza",
      title: "ASHOK SAMRAT Ep7 - YAKUZA",
      image: "https://res.cloudinary.com/dofeqwgfb/image/upload/v1743540582/OSHAkurFilms/v3vxxuxtoo9br4nbuxiy.jpg",
      timestamp: "a day ago",
    },
    {
      id: "winabi-savimbi",
      title: "WINABI - SAVIMBI",
      image: "https://res.cloudinary.com/dofeqwgfb/image/upload/v1743461523/OSHAkurFilms/jvd47elrh7axcqvsvixi.jpg",
      timestamp: "2 days ago",
    },
    {
      id: "house-of-david-ep7-savimbi",
      title: "House of David ep7 - Savimbi",
      image: "https://res.cloudinary.com/dofeqwgfb/image/upload/v1743460993/OSHAkurFilms/mbh4ppiagftbaiw7wfap.jpg",
      timestamp: "2 days ago",
    },
  ];

  // Sample data for hot seasons
  const hotSeasons = [
    {
      id: "the-shield-rocky",
      title: "THE SHIELD - ROCKY",
      image: "https://res.cloudinary.com/deucltufy/image/upload/v1743413414/OSHAkurFilms/eups2wkereatjv8stjk5.jpg",
      category: "ACTION",
    },
    {
      id: "ashok-samrat-ep1-yakuza",
      title: "ASHOK SAMRAT - YAKUZA",
      image: "https://res.cloudinary.com/deucltufy/image/upload/v1743354551/OSHAkurFilms/otkx9zenxiqkdwttpwym.jpg",
      category: "INDIAN",
    },
    {
      id: "cassandra-ep1-habibu",
      title: "CASSANDRA - HABIBU",
      image: "https://res.cloudinary.com/deucltufy/image/upload/v1743266645/OSHAkurFilms/w06ao0bdynxnqa8xxrhf.jpg",
      category: "SCIFI",
    },
    {
      id: "nine-bodie-ep1-gaheza",
      title: "NIine Bodie - Gaheza",
      image: "https://res.cloudinary.com/deucltufy/image/upload/v1743263349/OSHAkurFilms/cj4rxfb61xlzffpy5jsh.jpg",
      category: "ACTION",
    },
    {
      id: "house-of-david-ep1-savimbi",
      title: "House of David - SAVIMBI",
      image: "https://res.cloudinary.com/deucltufy/image/upload/v1742920194/OSHAkurFilms/x0zivggebkgm4jgsihba.jpg",
      category: "DRAMA",
    },
    {
      id: "house-of-david-ep1-habibu",
      title: "House of David - HABIBU",
      image: "https://res.cloudinary.com/deucltufy/image/upload/v1742687351/OSHAkurFilms/dyqqx1afvsldslpuqcrb.jpg",
      category: "DRAMA",
    },
  ];

  // Sample data for action movies
  const actionMovies = [
    {
      id: "trap-rocky",
      title: "TRAP - ROCKY",
      image: "https://res.cloudinary.com/deucltufy/image/upload/v1743353788/OSHAkurFilms/icfuh96q9jxi5zogbyhi.jpg",
      timestamp: "3 days ago",
      category: "ACTION",
    },
    {
      id: "the-cleaner-gaheza",
      title: "The Cleaner - Gaheza",
      image: "https://res.cloudinary.com/deucltufy/image/upload/v1742965942/OSHAkurFilms/zmhthie57mknlugvhzhy.jpg",
      timestamp: "8 days ago",
      category: "ACTION",
    },
    {
      id: "fateh-rocky",
      title: "FATEH - ROCKY",
      image: "https://res.cloudinary.com/dofeqwgfb/image/upload/v1741790011/OSHAkurFilms/ibn9p0i9nyyonlyubzus.jpg",
      timestamp: "21 days ago",
      category: "ACTION",
    },
    {
      id: "lioness-ep1-rocky",
      title: "LIONESS - ROCKY",
      image: "https://res.cloudinary.com/dofeqwgfb/image/upload/v1741583395/OSHAkurFilms/ddsnv2cf3a0gosewu9vp.jpg",
      timestamp: "25 days ago",
      category: "ACTION",
    },
    {
      id: "the-penguin-ep1-sankra",
      title: "The Penguin - SANKRA",
      image: "https://res.cloudinary.com/dofeqwgfb/image/upload/v1738785784/OSHAkurFilms/fv0aupquon8lydbiewl7.jpg",
      timestamp: "2 months ago",
      category: "ACTION",
    },
  ];

  // Sample data for Indian movies
  const indianMovies = [
    {
      id: "kaabil-rocky",
      title: "Kaabil - Rocky",
      image: "https://res.cloudinary.com/deucltufy/image/upload/v1743284727/OSHAkurFilms/pfontslxapicsmhcer4h.jpg",
      timestamp: "4 days ago",
      category: "INDIAN",
    },
    {
      id: "nadaaniyan-rocky",
      title: "Nadaaniyan - ROCKY",
      image: "https://res.cloudinary.com/deucltufy/image/upload/v1743173698/OSHAkurFilms/z9bzgzifkz6kwlpcadgh.jpg",
      timestamp: "5 days ago",
      category: "INDIAN",
    },
    {
      id: "samar-rocky",
      title: "SAMAR - ROCKY",
      image: "https://res.cloudinary.com/deucltufy/image/upload/v1742440799/OSHAkurFilms/klvszyvmrz0kvptvnruy.jpg",
      timestamp: "12 days ago",
      category: "INDIAN",
    },
    {
      id: "love-per-square-foot-savimbi",
      title: "Love Per square Foot - Savimbi",
      image: "https://res.cloudinary.com/deucltufy/image/upload/v1741932541/OSHAkurFilms/u2qtxdgdyhcpndytyqua.jpg",
      timestamp: "19 days ago",
      category: "INDIAN",
    },
  ];

  return (
    <main className="min-h-screen bg-oshakur-darkBg">
      <Header />

      <div className="container mx-auto px-4">
        <Hero featuredMovie={featuredMovie} />

        <MovieSection
          title="Trending Now"
          movies={trendingMovies}
          icon={<Flame size={16} className="text-oshakur-red" />}
        />

        <MovieSection
          title="Recent Movies"
          movies={recentMovies}
          icon={<Clock size={16} className="text-oshakur-red" />}
        />

        <MovieSection
          title="Hot Seasons"
          movies={hotSeasons}
          icon={<Calendar size={16} className="text-oshakur-red" />}
          cardSize="medium"
        />

        <MovieSection
          title="Action Movies"
          movies={actionMovies}
          icon={<Clapperboard size={16} className="text-oshakur-red" />}
          cardSize="medium"
        />

        <MovieSection
          title="Indian Movies"
          movies={indianMovies}
          icon={<Video size={16} className="text-oshakur-red" />}
          cardSize="medium"
        />
      </div>

      <Footer />
    </main>
  );
}
