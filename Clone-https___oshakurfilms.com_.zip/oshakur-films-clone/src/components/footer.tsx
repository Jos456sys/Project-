import React from "react";
import Link from "next/link";

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-oshakur-darkBg2 text-white py-10 mt-12">
      <div className="container px-4 mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-lg font-semibold mb-4">Most Recently</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/watch/ashok-samrat-ep10-yakuza" className="text-gray-300 hover:text-white transition-colors">
                  ASHOK SAMRAT Ep10 - YAKUZA
                </Link>
              </li>
              <li>
                <Link href="/watch/ashok-samrat-ep9-yakuza" className="text-gray-300 hover:text-white transition-colors">
                  ASHOK SAMRAT Ep9 - YAKUZA
                </Link>
              </li>
              <li>
                <Link href="/watch/ashok-samrat-ep7-yakuza" className="text-gray-300 hover:text-white transition-colors">
                  ASHOK SAMRAT Ep7 - YAKUZA
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Social Media</h3>
            <ul className="space-y-2">
              <li>
                <Link
                  href="https://www.youtube.com/channel/UC9yK7Ep1uXLD8t72dBVYGrw"
                  target="_blank"
                  className="text-gray-300 hover:text-white transition-colors"
                >
                  YouTube
                </Link>
              </li>
              <li>
                <Link
                  href="https://www.instagram.com/oshakurfilms"
                  target="_blank"
                  className="text-gray-300 hover:text-white transition-colors"
                >
                  Instagram
                </Link>
              </li>
              <li>
                <Link
                  href="https://www.tiktok.com/@rockykimomonew?_t=8jF8BdAh6iT&_r=1"
                  target="_blank"
                  className="text-gray-300 hover:text-white transition-colors"
                >
                  TikTok
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/about-us" className="text-gray-300 hover:text-white transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="tel:+250788821628" className="text-gray-300 hover:text-white transition-colors">
                  +250 788 821 628
                </Link>
              </li>
              <li>
                <Link href="mailto:mnybgngolivier@gmail.com" className="text-gray-300 hover:text-white transition-colors">
                  mnybgngolivier@gmail.com
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8 text-center text-sm text-gray-400">
          <p>Copyright &copy; {currentYear} OSHAkur Films. All Rights Reserved.</p>
          <div className="mt-2">
            <Link href="/watch/privacy" className="hover:text-white transition-colors">
              Privacy Policy
            </Link>
            {" and "}
            <Link href="/watch/privacy" className="hover:text-white transition-colors">
              Terms & Conditions
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
