import React from "react";
import Image from "next/image";
import Link from "next/link";
import { Play } from "lucide-react";

interface HeroProps {
  featuredMovie: {
    id: string;
    title: string;
    image: string;
    releaseDate: string;
  };
}

const Hero: React.FC<HeroProps> = ({ featuredMovie }) => {
  return (
    <div className="relative w-full h-[60vh] min-h-[400px] mb-8">
      <div className="absolute inset-0">
        <Image
          src={featuredMovie.image}
          alt={featuredMovie.title}
          fill
          className="object-cover object-center"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-t from-oshakur-darkBg via-oshakur-darkBg/90 to-transparent" />
      </div>

      <div className="absolute bottom-0 left-0 p-6 md:p-8 w-full">
        <div className="max-w-lg">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
            {featuredMovie.title}
          </h1>
          <p className="text-gray-300 mb-4">Released {featuredMovie.releaseDate}</p>

          <div className="flex space-x-4">
            <Link href={`/watch/${featuredMovie.id}`} className="red-button">
              <Play className="h-4 w-4" />
              PLAY TRAILER
            </Link>
          </div>
        </div>
      </div>

      <div className="absolute right-0 top-0 p-4">
        <Link
          href="https://whatsapp.com/channel/0029VaeMnzYFcowEUV04lG0M"
          target="_blank"
          className="flex items-center bg-oshakur-darkBg2/80 backdrop-blur-sm text-white p-2 rounded-md text-sm"
        >
          <svg
            className="w-4 h-4 mr-2"
            viewBox="0 0 24 24"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M10.05 2.53004L4.03002 6.46004C2.10002 7.72004 2.10002 10.54 4.03002 11.8L10.05 15.73C11.13 16.44 12.91 16.44 13.99 15.73L19.98 11.8C21.9 10.54 21.9 7.73004 19.98 6.47004L13.99 2.54004C12.91 1.82004 11.13 1.82004 10.05 2.53004Z"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M5.63 13.08L5.62 17.77C5.62 19.04 6.6 20.4 7.8 20.8L10.99 21.86C11.54 22.04 12.45 22.04 13.01 21.86L16.2 20.8C17.4 20.4 18.38 19.04 18.38 17.77V13.13"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M21.4 15V9"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          Follow us on WhatsApp for movies updates
        </Link>
      </div>
    </div>
  );
};

export default Hero;
