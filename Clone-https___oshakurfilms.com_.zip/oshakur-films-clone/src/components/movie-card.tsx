import React from "react";
import Image from "next/image";
import Link from "next/link";

interface MovieCardProps {
  id: string;
  title: string;
  image: string;
  category?: string;
  uploader?: string;
  timestamp?: string;
  size?: "small" | "medium" | "large";
}

const MovieCard = ({
  id,
  title,
  image,
  category,
  uploader,
  timestamp,
  size = "medium",
}: MovieCardProps) => {
  const sizes = {
    small: "w-36 h-48",
    medium: "w-44 h-60",
    large: "w-full h-64",
  };

  return (
    <Link href={`/watch/${id}`}>
      <div className={`movie-card ${sizes[size]} relative`}>
        {category && (
          <div className="badge">{category}</div>
        )}
        <div className="relative h-full w-full">
          <Image
            src={image}
            alt={title}
            fill
            className="object-cover rounded-md"
          />
          <div className="overlay">
            <h3 className="text-sm font-medium line-clamp-2">{title}</h3>
            <div className="flex items-center mt-1">
              {timestamp && (
                <p className="text-xs text-gray-300">{timestamp}</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default MovieCard;
