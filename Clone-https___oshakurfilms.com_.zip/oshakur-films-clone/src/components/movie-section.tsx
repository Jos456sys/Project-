import React from "react";
import Link from "next/link";
import { ChevronLeft, ChevronRight, Flame } from "lucide-react";
import MovieCard from "./movie-card";

interface Movie {
  id: string;
  title: string;
  image: string;
  category?: string;
  uploader?: string;
  timestamp?: string;
}

interface MovieSectionProps {
  title: string;
  movies: Movie[];
  icon?: React.ReactNode;
  viewAllLink?: string;
  cardSize?: "small" | "medium" | "large";
}

const MovieSection: React.FC<MovieSectionProps> = ({
  title,
  movies,
  icon = <Flame size={16} className="text-oshakur-red" />,
  viewAllLink,
  cardSize = "medium",
}) => {
  const scrollContainerRef = React.useRef<HTMLDivElement>(null);

  const scrollLeft = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({
        left: -250,
        behavior: "smooth",
      });
    }
  };

  const scrollRight = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({
        left: 250,
        behavior: "smooth",
      });
    }
  };

  return (
    <section className="mb-8">
      <div className="flex items-center justify-between mb-4">
        <div className="section-heading flex items-center gap-2">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            {icon}
            {title}
          </h2>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={scrollLeft}
            className="p-1 rounded-full bg-oshakur-darkBg2 hover:bg-oshakur-red/30 transition-colors"
            aria-label="Scroll left"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          <button
            onClick={scrollRight}
            className="p-1 rounded-full bg-oshakur-darkBg2 hover:bg-oshakur-red/30 transition-colors"
            aria-label="Scroll right"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div
        ref={scrollContainerRef}
        className="flex overflow-x-auto pb-4 gap-4 scrollbar-hide"
        style={{ scrollbarWidth: "none" }}
      >
        {movies.map((movie) => (
          <div key={movie.id} className="flex-shrink-0">
            <MovieCard
              id={movie.id}
              title={movie.title}
              image={movie.image}
              category={movie.category}
              timestamp={movie.timestamp}
              uploader={movie.uploader}
              size={cardSize}
            />
          </div>
        ))}
      </div>
    </section>
  );
};

export default MovieSection;
